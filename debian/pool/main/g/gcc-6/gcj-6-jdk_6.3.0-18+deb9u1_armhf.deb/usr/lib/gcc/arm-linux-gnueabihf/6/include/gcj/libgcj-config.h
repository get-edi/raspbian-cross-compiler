/* gcj/libgcj-config.h.  Generated from libgcj-config.h.in by configure.  */
/* The header file derived from this file is installed in a target and
   compiler version specific directory.  Do not add definitions which
   are intended to be different for different multilibs, as we do not
   currently have a mechanism to support this.

   Also be sure to use safely named macros, as this file will be 
   included in user code.  */

/* Define if hash synchronization is in use.  */
/* #undef JV_HASH_SYNCHRONIZATION */

/* Define if <inttypes.h> is available.  */
#define JV_HAVE_INTTYPES_H 1
